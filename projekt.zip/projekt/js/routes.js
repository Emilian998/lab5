angular.module('app.routes', ['ionicUIRouter'])

.config(function($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider
    
  

      .state('stronaGWna.quiz', {
    url: '/page2',
    views: {
      'tab2': {
        templateUrl: 'templates/quiz.html',
        controller: 'quizCtrl'
      }
    }
  })

  .state('stronaGWna.wydziaY', {
    url: '/page3',
    views: {
      'tab3': {
        templateUrl: 'templates/wydziaY.html',
        controller: 'wydziaYCtrl'
      }
    }
  })

  .state('homepage', {
    url: '/',
    templateUrl: 'templates/homepage.html',
    controller: 'homepageCtrl'
  })

  .state('stronaGWna', {
    url: '/page1',
    templateUrl: 'templates/stronaGWna.html',
    abstract:true
  })

  /* 
    The IonicUIRouter.js UI-Router Modification is being used for this route.
    To navigate to this route, do NOT use a URL. Instead use one of the following:
      1) Using the ui-sref HTML attribute:
        ui-sref='stronaGWna.studia'
      2) Using $state.go programatically:
        $state.go('stronaGWna.studia');
    This allows your app to figure out which Tab to open this page in on the fly.
    If you're setting a Tabs default page or modifying the .otherwise for your app and
    must use a URL, use one of the following:
      /page1/tab1/page5
      /page1/tab2/page5
  */
  .state('stronaGWna.studia', {
    url: '/page5',
    views: {
      'tab1': {
        templateUrl: 'templates/studia.html',
        controller: 'studiaCtrl'
      },
      'tab2': {
        templateUrl: 'templates/studia.html',
        controller: 'studiaCtrl'
      }
    }
  })

  .state('stronaGWna.mechaniczny', {
    url: '/page6',
    views: {
      'tab3': {
        templateUrl: 'templates/mechaniczny.html',
        controller: 'mechanicznyCtrl'
      }
    }
  })

  .state('stronaGWna.elektryczny', {
    url: '/page7',
    views: {
      'tab3': {
        templateUrl: 'templates/elektryczny.html',
        controller: 'elektrycznyCtrl'
      }
    }
  })

  .state('stronaGWna.nawigacyjny', {
    url: '/page8',
    views: {
      'tab3': {
        templateUrl: 'templates/nawigacyjny.html',
        controller: 'nawigacyjnyCtrl'
      }
    }
  })

  .state('stronaGWna.wPiT', {
    url: '/page9',
    views: {
      'tab3': {
        templateUrl: 'templates/wPiT.html',
        controller: 'wPiTCtrl'
      }
    }
  })

  .state('pytanie1', {
    url: '/page10',
    templateUrl: 'templates/pytanie1.html',
    controller: 'pytanie1Ctrl'
  })

  .state('pytanie2', {
    url: '/page11',
    templateUrl: 'templates/pytanie2.html',
    controller: 'pytanie2Ctrl'
  })

  .state('pytanie3', {
    url: '/page12',
    templateUrl: 'templates/pytanie3.html',
    controller: 'pytanie3Ctrl'
  })

  .state('pytanie4', {
    url: '/page13',
    templateUrl: 'templates/pytanie4.html',
    controller: 'pytanie4Ctrl'
  })

  .state('pytanie5', {
    url: '/page14',
    templateUrl: 'templates/pytanie5.html',
    controller: 'pytanie5Ctrl'
  })

  .state('przegrana', {
    url: '/page15',
    templateUrl: 'templates/przegrana.html',
    controller: 'przegranaCtrl'
  })

  .state('stronaGWna.wygrana', {
    url: '/page16',
    views: {
      'tab2': {
        templateUrl: 'templates/wygrana.html',
        controller: 'wygranaCtrl'
      }
    }
  })

  .state('stronaGWna.iStopienWM', {
    url: '/page17',
    views: {
      'tab3': {
        templateUrl: 'templates/iStopienWM.html',
        controller: 'iStopienWMCtrl'
      }
    }
  })

  .state('stronaGWna.iIStopieWM', {
    url: '/page18',
    views: {
      'tab3': {
        templateUrl: 'templates/iIStopieWM.html',
        controller: 'iIStopieWMCtrl'
      }
    }
  })

  .state('stronaGWna.iStopieWE', {
    url: '/page19',
    views: {
      'tab3': {
        templateUrl: 'templates/iStopieWE.html',
        controller: 'iStopieWECtrl'
      }
    }
  })

  .state('stronaGWna.iIStopieWE', {
    url: '/page20',
    views: {
      'tab3': {
        templateUrl: 'templates/iIStopieWE.html',
        controller: 'iIStopieWECtrl'
      }
    }
  })

  .state('stronaGWna.iStopieWN', {
    url: '/page21',
    views: {
      'tab3': {
        templateUrl: 'templates/iStopieWN.html',
        controller: 'iStopieWNCtrl'
      }
    }
  })

  .state('stronaGWna.iIStopieWN', {
    url: '/page22',
    views: {
      'tab3': {
        templateUrl: 'templates/iIStopieWN.html',
        controller: 'iIStopieWNCtrl'
      }
    }
  })

  .state('stronaGWna.iStopieWPiT', {
    url: '/page23',
    views: {
      'tab3': {
        templateUrl: 'templates/iStopieWPiT.html',
        controller: 'iStopieWPiTCtrl'
      }
    }
  })

  .state('stronaGWna.iIStopieWPiT', {
    url: '/page24',
    views: {
      'tab3': {
        templateUrl: 'templates/iIStopieWPiT.html',
        controller: 'iIStopieWPiTCtrl'
      }
    }
  })

  .state('stronaGWna.galeria', {
    url: '/page26',
    views: {
      'tab2': {
        templateUrl: 'templates/galeria.html',
        controller: 'galeriaCtrl'
      }
    }
  })

$urlRouterProvider.otherwise('/page1/tab1/page5')

  

});